import pandas as pd

data = pd.read_csv("time_series_covid19_deaths_global.csv")
headers = list(data.columns.values)
headers = headers[4:]

data2 = pd.read_csv("time_series_covid19_recovered_global.csv")
headers2 = list(data2.columns.values)
headers2 = headers2[4:]


data3 = pd.read_csv("time_series_covid19_confirmed_global.csv")

headers3 = list(data3.columns.values)
headers3 = headers3[4:]

if (headers == headers2):
    if (headers == headers3):
        print(True)
else:
    print(False)

data_owid = pd.read_csv("owid-covid-data.csv")
data_owid = data_owid['date']
data_owid = pd.DataFrame(data_owid)

data_time_series = pd.DataFrame(headers, columns=["dates"])
data_owid = data_owid.drop_duplicates()

data_time_series["dates"] = pd.to_datetime(data_time_series["dates"])

#print(data_time_series.dtypes)
data_owid.columns = ["dates"]
data_owid["dates"] = pd.to_datetime(data_owid["dates"])
#print(data_owid.dtypes)
dates_extra = data_time_series[~data_time_series.isin(data_owid)]

frames = [data_owid, data_time_series]
result = pd.concat(frames)
result = result.drop_duplicates()
result.to_csv("times.csv", header=False)
result['month'] = pd.DatetimeIndex(result['dates']).month
result['quarter'] = pd.DatetimeIndex(result['dates']).quarter
result['year'] = pd.DatetimeIndex(result['dates']).year

result = result[['month', 'quarter', 'year']]
result = result.drop_duplicates()
result = result.reset_index()
result = result[['month', 'quarter', 'year']]
#print(result)
result.to_csv("times.csv", header=False)

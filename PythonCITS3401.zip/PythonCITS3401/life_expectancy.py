import pandas as pd
data_owid = pd.read_csv("owid-covid-data.csv") #Reads the file
data_loc = pd.read_csv("locations.csv", names=['index', 'Country', 'Alternate Name', 'Continent']) #Reads file locations which we have just made
data_loc = data_loc[['index', 'Country', 'Continent']] #GEtting only the tables required
data_owid = data_owid[['location', 'life_expectancy']].drop_duplicates() #Getting only the required data and dropping duplicates
data_life = pd.merge(data_owid, data_loc, how='inner', left_on='location', right_on='Country') #Can use inner join here because we know that location has every Country name in it.
data_life = data_life.fillna(0)
data_life['greater_than_75'] = data_life['life_expectancy'] > 75 #Checking whether the life expectancy in countries is more than 75 or not
#data_life = data_life[['index', 'greater_than_75']] #Keeping only required columns for our queries
#data_life.to_csv("life_expectancy.csv", header=False) #

data_life_updated = data_life[['greater_than_75']] #Keeping only required columns for our queries
data_life_updated = data_life_updated.drop_duplicates()
data_life_updated.to_csv("actual_life_expectancy.csv", header=False)

import pandas as pd
import numpy as np
data_owid = pd.read_csv("owid-covid-data.csv")
data_deaths = pd.read_csv("time_series_covid19_deaths_global.csv")
data_confirmed = pd.read_csv("time_series_covid19_confirmed_global.csv")
data_recovered = pd.read_csv("time_series_covid19_recovered_global.csv")
times = pd.read_csv("time.py", names=["time_index", "month", "quarter", "year"])
locations = pd.read_csv("locations.csv", names=['loc_index', 'Country', 'Alternate Name', 'Continent'])
life_exp = pd.read_csv("life_expectancy.csv", names=["life_index", "life_country_index", "greater_than_75"])

population = pd.read_csv("population.csv", names=["pop_index", "pop_loc_index", "pop_size"])
real_pop = pd.read_csv("actual_population.csv", names=["population_index", "population_size"])

data_owid_loc = pd.merge(data_owid, locations, how='inner', left_on='location', right_on='Country')
data_owid_pop_loc = pd.merge(data_owid_loc, population, how='inner', left_on='loc_index', right_on='pop_loc_index')
data_owid_pop_loc = pd.merge(data_owid_pop_loc, real_pop, how='inner', left_on='pop_size', right_on='population_size')

real_life_exp = pd.read_csv("actual_life_expectancy.csv", names=['life_exp_index', 'over_75'])
data_owid_pop_loc_life = pd.merge(data_owid_pop_loc, life_exp, how='inner', left_on='loc_index', right_on='life_country_index')
data_owid_pop_loc_life = pd.merge(data_owid_pop_loc_life, real_life_exp, how='inner', left_on='greater_than_75', right_on='over_75')

data_owid_pop_loc_life["date"] = pd.to_datetime(data_owid_pop_loc_life["date"])
data_owid_pop_loc_life["day"] = pd.DatetimeIndex(data_owid_pop_loc_life["date"]).day


data_recovered = data_recovered.melt(id_vars=["Province/State", "Country/Region", "Lat", "Long"],
        var_name="Date",
        value_name="Recovered_cases")
data_deaths = data_deaths.melt(id_vars=["Province/State", "Country/Region", "Lat", "Long"],
        var_name="Date",
        value_name="Death_cases")
data_confirmed = data_confirmed.melt(id_vars=["Province/State", "Country/Region", "Lat", "Long"],
        var_name="Date",
        value_name="Confirmed_cases")

data_recovered["Rec_Date"] = pd.to_datetime(data_recovered["Date"])
data_deaths["Dea_Date"] = pd.to_datetime(data_deaths["Date"])
data_confirmed["Con_Date"] = pd.to_datetime(data_confirmed["Date"])

data_confirmed["Country/Region"].replace({"US": "United States", "Cabo Verde": "Cape Verde", "Burma": "Myanmar", "Congo (Brazzaville)": "Congo", "Congo (Kinshasa)": "Democratic Republic of Congo", "Holy See": "Vatican", "Korea, South": "South Korea", "Taiwan*": "Taiwan", "Timor-Leste": "Timor", "West Bank and Gaza": "Palestine"}, inplace=True)
data_deaths["Country/Region"].replace({"US": "United States", "Cabo Verde": "Cape Verde", "Burma": "Myanmar", "Congo (Brazzaville)": "Congo", "Congo (Kinshasa)": "Democratic Republic of Congo", "Holy See": "Vatican", "Korea, South": "South Korea", "Taiwan*": "Taiwan", "Timor-Leste": "Timor", "West Bank and Gaza": "Palestine"}, inplace=True)
data_recovered["Country/Region"].replace({"US": "United States", "Cabo Verde": "Cape Verde", "Burma": "Myanmar", "Congo (Brazzaville)": "Congo", "Congo (Kinshasa)": "Democratic Republic of Congo", "Holy See": "Vatican", "Korea, South": "South Korea", "Taiwan*": "Taiwan", "Timor-Leste": "Timor", "West Bank and Gaza": "Palestine"}, inplace=True)

grouped_recovered = data_recovered

grouped_recovered['the_date'] = pd.DatetimeIndex(data_recovered['Rec_Date']).day
grouped_recovered['month'] = pd.DatetimeIndex(data_recovered['Rec_Date']).month
grouped_recovered['quarter'] = pd.DatetimeIndex(data_recovered['Rec_Date']).quarter
grouped_recovered['year'] = pd.DatetimeIndex(data_recovered['Rec_Date']).year
grouped_recovered['year'] = np.where(grouped_recovered['year'] == 2021, 12, grouped_recovered['year'])
grouped_recovered['year'] = np.where(grouped_recovered['year'] == 2020, 0, grouped_recovered['year'])
grouped_recovered['date'] = grouped_recovered['year'] + grouped_recovered['month'] - 1

grouped_recovered = grouped_recovered.groupby(['Country/Region', 'date', 'the_date']).agg({'Recovered_cases': sum, 'month': sum, 'quarter': sum, 'year': sum})
grouped_recovered = grouped_recovered.reset_index()

the_day_column = list(grouped_recovered['Recovered_cases'])
the_day_column.pop()
the_day_column.insert(0, 0)
the_day_column = pd.DataFrame(the_day_column)

grouped_recovered['the_subtract_data'] = the_day_column
grouped_recovered['Recovered_per_day'] = grouped_recovered['Recovered_cases'] - grouped_recovered['the_subtract_data']

grouped_confirmed = data_confirmed

grouped_confirmed['the_date'] = pd.DatetimeIndex(data_confirmed['Con_Date']).day
grouped_confirmed['month'] = pd.DatetimeIndex(data_confirmed['Con_Date']).month
grouped_confirmed['quarter'] = pd.DatetimeIndex(data_confirmed['Con_Date']).quarter
grouped_confirmed['year'] = pd.DatetimeIndex(data_confirmed['Con_Date']).year
grouped_confirmed['year'] = np.where(grouped_confirmed['year'] == 2021, 12, grouped_confirmed['year'])
grouped_confirmed['year'] = np.where(grouped_confirmed['year'] == 2020, 0, grouped_confirmed['year'])
grouped_confirmed['date'] = grouped_confirmed['year'] + grouped_confirmed['month'] - 1

grouped_confirmed = grouped_confirmed.groupby(['Country/Region', 'date', 'the_date']).agg({'Confirmed_cases': sum, 'month': sum, 'quarter': sum, 'year': sum})
grouped_confirmed = grouped_confirmed.reset_index()

the_day_column = list(grouped_confirmed['Confirmed_cases'])
the_day_column.pop()
the_day_column.insert(0, 0)
the_day_column = pd.DataFrame(the_day_column)

grouped_confirmed['the_subtract_data'] = the_day_column
grouped_confirmed['Confirmed_per_day'] = grouped_confirmed['Confirmed_cases'] - grouped_confirmed['the_subtract_data']

grouped_deaths = data_deaths
#grouped_deaths['actual_dateD'] = data_deaths['Dea_Date']
grouped_deaths['the_date'] = pd.DatetimeIndex(data_deaths['Dea_Date']).day
grouped_deaths['month'] = pd.DatetimeIndex(data_deaths['Dea_Date']).month
grouped_deaths['quarter'] = pd.DatetimeIndex(data_deaths['Dea_Date']).quarter
grouped_deaths['year'] = pd.DatetimeIndex(data_deaths['Dea_Date']).year
grouped_deaths['year'] = np.where(grouped_deaths['year'] == 2021, 12, grouped_deaths['year'])
grouped_deaths['year'] = np.where(grouped_deaths['year'] == 2020, 0, grouped_deaths['year'])
grouped_deaths['date'] = grouped_deaths['year'] + grouped_deaths['month'] - 1


grouped_deaths = grouped_deaths.groupby(['Country/Region', 'date', 'the_date']).agg({'Death_cases': sum, 'month': sum, 'quarter': sum, 'year': sum})
grouped_deaths = grouped_deaths.reset_index()

the_day_column = list(grouped_deaths['Death_cases'])
the_day_column.pop()
the_day_column.insert(0, 0)
the_day_column = pd.DataFrame(the_day_column)

grouped_deaths['the_subtract_data'] = the_day_column
grouped_deaths['Deaths_per_day'] = grouped_deaths['Death_cases'] - grouped_deaths['the_subtract_data']


grouped_fact_data = grouped_confirmed

grouped_fact_data.to_csv("combiningAttempt.csv", header=True)
grouped_fact_data['Deaths_data'] = grouped_deaths['Deaths_per_day']
grouped_fact_data['Recovered_data'] = grouped_recovered['Recovered_per_day']

final_data = pd.merge(data_owid_pop_loc_life, grouped_fact_data, how="right", left_on=["location", "day"], right_on=["Country/Region", "the_date"])

final_data = final_data[["day", "location", "loc_index", "date_y", "population_index", "life_exp_index", "Confirmed_per_day", "Deaths_data", "Recovered_data"]]
final_data = final_data.drop_duplicates()
#df[df > 9] = 11
final_data["Confirmed_per_day"][final_data["Confirmed_per_day"] < -50] = 0
final_data["Deaths_data"][final_data["Deaths_data"] < -50] = 0
final_data["Recovered_data"][final_data["Recovered_data"] < -50] = 0
final_data = final_data.fillna(0)

final_data = final_data[["date_y", "loc_index", "population_index", "life_exp_index", "Confirmed_per_day", "Recovered_data", "Deaths_data"]]

final_data.to_csv("combiningAttempt.csv", header=False)
import pandas as pd
import numpy as np

f = open("time_series_covid19_confirmed_global.csv", "r")
confirmed_cases_list = []
for i in f:
    i = i.split(",")
    confirmed_cases_list.append(i)

#print(confirmed_cases_list[1][1])

locations_list = []
arrayLength = len(confirmed_cases_list[0])
locations_list_data = []
for each in confirmed_cases_list:
    #locations_list.append(each[1:])
    locations_list_data.append(each[(len(each)-arrayLength+2):])#Some of the names have commas so I separated data from names
#print(type(locations_list[1][1]))
locations_list_data = locations_list_data[1:]
new_locations = []
for ele in locations_list_data:
    ele = [0 if each == "" else each for each in ele]
    new_locations.append(ele)
locations_list_data = new_locations

removed_items = []
locations = []
indexes_removed = []
index = 1
for each in locations_list_data:
    #print(each[0])
    if int(float(each[0])) == 0 and int(float(each[1])) == 0:
        removed_items.append(each)
        indexes_removed.append(index)
    elif each[0] is not None and each[1] is not None:
        locations.append(each)
    index += 1
indexArray = []

#print(confirmed_cases_list[1:])
for i in range(len(confirmed_cases_list)-1):
    indexArray.append(i)
for removeIndex in indexes_removed:
    indexArray.remove(removeIndex)
locIndex = 0
for index in indexArray:
    #print(confirmed_cases_list[1:][index][1])
    locations[locIndex].insert(0, confirmed_cases_list[1:][index][1])
    locIndex += 1

locationsNew = []
for each in locations:
    locThis = [each[0]]
    for ele in each[1:]:
        locThis.append(float(ele))
    locationsNew.append(locThis)
locationsConverted = []
#print(locationsNew)
for every in locationsNew:
    locThis = []
    for dim in range(3):
        locThis.append(every[dim])
    for ele in every[3:]:
        locThis.append(int(ele))
    locationsConverted.append(locThis)


currentLoc = locationsConverted[0]
repeats = 1
finalResult = []
for row in locationsConverted[1:]:
    if currentLoc[0] == row[0]:
        currentLoc[1:] += row[1:]
        repeats += 1
    else:
        #currentLoc[1] = currentLoc[1]/repeats
        #currentLoc[2] = currentLoc[2]/repeats
        finalResult.append(currentLoc)
        currentLoc = row
        repeats = 1


data = pd.read_csv("time_series_covid19_confirmed_global.csv") #reads csv file
data = data.fillna(0) #Fills in 0 for every empty location in the dataframe
data_countries = data['Country/Region'] #collecting the list of countries from times_series files.
data_countries = data_countries.drop_duplicates() #dropping any repitition
data = data.groupby(['Country/Region']).sum()
data = data[data.columns[2:]]
data2 = pd.read_csv("owid-covid-data.csv") #reads owid data file and stores it in data2
data2 = data2.fillna(0)
data2 = data2[['location', 'continent']]
data2 = data2.drop_duplicates()

data3 = pd.merge(data, data2, how='inner', left_on='Country/Region', right_on='location')
data4 = pd.merge(data, data2, how="outer", left_on="Country/Region", right_on="location")


data2_loc = data2['location']
data2_removed_countries = data2[~data2['location'].isin(data3['location'])]

data_removed_countries = data_countries[~data_countries.isin(data3['location'])]
data4 = data4.fillna(0)
print(data2_removed_countries)
print(data_removed_countries)
data3 = data3.append(data4[data4['location'] == 'United States'])
data3 = data3.append(data4[data4['location'] == 'Cape Verde'])
data3 = data3.append(data4[data4['location'] == 'Congo'])
data3 = data3.append(data4[data4['location'] == 'Democratic Republic of Congo'])
data3 = data3.append(data4[data4['location'] == 'Myanmar'])
data3 = data3.append(data4[data4['location'] == 'South Korea'])
data3 = data3.append(data4[data4['location'] == 'Vatican'])
data3 = data3.append(data4[data4['location'] == 'Taiwan'])
data3 = data3.append(data4[data4['location'] == 'Palestine'])
data3 = data3.append(data4[data4['location'] == 'Timor'])
#data_life['size'] = np.where(data_life['size'] == True, "large", data_life['size'])
data3["alternate_location"] = ""
data3["alternate_location"] = np.where(data3['location'] == "United States", "US", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Cape Verde", "Cabo Verde", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Myanmar", "Burma", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Congo", "Congo (Brazzaville)", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Democratic Republic of Congo", "Congo (Kinshasa)", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Vatican", "Holy See", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "South Korea", "Korea, South", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Taiwan", "Taiwan*", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Timor", "Timor-Leste", data3["alternate_location"])
data3["alternate_location"] = np.where(data3['location'] == "Palestine", "West Bank and Gaza", data3["alternate_location"])


#print(data3)
locations = data3[['location', 'alternate_location', 'continent']].reset_index().reset_index()
locations = locations[['location', 'alternate_location', 'continent']]
locations.to_csv("locations.csv", header=False)
print(locations)
